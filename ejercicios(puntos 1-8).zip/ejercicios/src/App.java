public class App {

    public static void main(String[] args) throws Exception {
        Puntos puntos=new Puntos();

        //puntos.primerPunto();
        //puntos.segundoPunto(3);
        //puntos.tercerPunto();
        //puntos.cuartoPunto();
        //puntos.quintoPunto();
        //puntos.sextoPunto();
        //puntos.septimoPunto();
        puntos.octavoPunto();
    }


    
}
