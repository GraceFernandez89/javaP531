import java.util.Random;
import java.util.Scanner;
/**
 * Ejercicios de la unidad 1 del segundo ciclo del curso de programacion de mintic
 */
public class Puntos {
    private Scanner scan;
    

    public Puntos(){
        scan=new Scanner(System.in);
        
    }
    /**
     * Solucion del primer punto
     */
    public void primerPunto(){
        String mensaje="la %c de %.2f y %.2f es igual a %.2f";
        System.out.println("Ingrese el primer numero");
        float numero_1=scan.nextFloat();
        System.out.println("Ingrese el segundo numero");
        float numero_2=scan.nextFloat();
        char []operaciones={'+','-','/','*'};
        for (char operacion : operaciones) {
            System.out.println(String.format(mensaje, operacion, numero_1,numero_2,(operaciones(numero_1, numero_2, operacion))));
        }
        
    }

    /**
     * Operacion entre dos numeros dados, si no se ingresa una operacion permitida, se retornara '0'
     * @param numero_1
     * @param numero_2
     * @param operacion char con el tipo de operacion a realizar, se permiten ={'+','-','/','*'}
     * @return operacion entre el numero 1 y el numero 2 respectivamente
     */
    private  float operaciones(float numero_1, float numero_2, char operacion) {
        //Declaracion de variable auxiliar
        float resultado=0;

        //Evaluando el tipo de operacion que se esta pidiendo realizar
        switch(operacion){
            case '+':
                resultado=numero_1+numero_2;
                break;
            case '-':
                resultado=numero_1-numero_2;
                break;
            case '/':
                resultado=numero_1/numero_2;    
                break;
            case '*':
                resultado=numero_1*numero_2;
                break;
            default:
                resultado=0;
        }
        return resultado;
    }



    /**
     * Solucion del segundo punto
     * @param n cantidad de notas por alumno
     */
    public void segundoPunto(int n){
        //Variables locales para un uso ordenado
        String nombre_estudiante;
        Float [] notas=new Float[n];
        boolean is_aprobado=false;
        String mensaje="El estudiante %s a %s";

        //Recibiendo el nombre del usuario desde consola
        System.out.println("Porfavor ingrese el nombre del estudiante : ");
        nombre_estudiante=scan.nextLine();
        
        //recibiendo las notas desde consola
        for(int i=0; i<n;i++){
            System.out.println("Ingrese el valor de la nota #"+(i+1));
            notas[i]=scan.nextFloat();
        }

        //Llamando a la funcion auxiliar "promedio()" para calcular lel promedio de las "notas"
        //Y evaluando si la nota promedio es mayor/igual a 3.0,
        is_aprobado=promedio(notas)>=3.0;

        //Imprimiendo el "mensaje" con el formateo correspondiente
        System.out.println(String.format(mensaje,nombre_estudiante,(is_aprobado)?"aprobado":"reprobado"));
    }
    


    /**
     * Calcula el promedio de las notas pasadas
     * @param notas arreglo de notas, tantos como se quieran
     * @return el promedio de las notas pasadas
     */
    private float promedio(Float... notas){
        float acumulador=0;
        //recorriendo los datos de "notas" para acumular sus valores
        for(float nota: notas){
            acumulador+=nota;
        }
        return acumulador/notas.length;

    }

    

    /**
     * Solucion del tercer punto
     * Calcula el sueldo a partir de las horas trabajadas(se ingresan por consola)
     * @param sueldo_por_hora valor del sueldo por hora
     */
    public void tercerPunto(float sueldo_por_hora){
        System.out.println("Ingrese la cantidad de horas trabajadas : ");
        float horas=scan.nextFloat();

        System.out.println("El trabajador ha ganado : "+horas*sueldo_por_hora);
    }
    
    /**
     * Calcula el sueldo a partir de las horas trabajadas(se ingresan por consola) y un sueldo por hora de 30000
     */
    public void tercerPunto(){
        tercerPunto(30000);
    }


    /**
     * Solucion del cuarto punto
     * @param cantidad cantidad de datos de la tabla de multiplicar
     */
    public void cuartoPunto(int cantidad){
        System.out.println("Digite el numero del cual quiere la tabla de multiplicar");
        //pidiendo el numero por consola
        int n=scan.nextInt();
        tablaDeMultiplicar(n, cantidad);

    }

    /**
     * Solución del cuarto punto con 10 datos de la tabla de multiplicar
     */
    public void cuartoPunto(){
        cuartoPunto(10);
    }

    /**
     * imprime la tabla de multiplicar de un numero "n"
     * @param n numero al que se le sacara la tabla de multiplicar
     * @param cantidad cuantos datos de la tabla de multiplicar se calcularan
     */
    private void tablaDeMultiplicar(int n,int cantidad){
        for(int i=1;i<=cantidad;i++){
            System.out.println(n+" x "+i+" = "+(n*i) );
        }
    }
    /**
     * Solucion del quinto punto
     * Calcula un numero aleatorio comprendido entre los limites(los incluye), y pide 
     * por consola un numero, el programa continuara hasta que se halla acertado el numero
     * @param limiteInferior numero mas bajo a generar
     * @param limiteSuperior numero mas alto a generar
     */
    public void quintoPunto(int limiteInferior,int limiteSuperior){
        //Generando numero aleatorio
        
        int numero_aleatorio=(int)Math.random()*limiteSuperior+limiteInferior;
        int entrada;
        //System.out.println(numero_aleatorio+"");
        while(true){
            System.out.println("Introduzca un numero entre "+limiteInferior+" y "+limiteSuperior);
            entrada=scan.nextInt();
            if(entrada==numero_aleatorio){
                System.out.println("Correcto, ese es su numero");
                break;
            }else if(entrada>numero_aleatorio)
                System.out.print("El número que busca es menor, ");
            else
                System.out.print("El número que busca es mayor, ");
            System.out.println("vuelva a intentarlo");
        };
    }

    /**
     * Solucion del quinto punto para numeros comprendidos entres 1 y 100
     */
    public void quintoPunto(){
        quintoPunto(1,100);
    }


    /**
     * Solucion del sexto punto
     */
    public void sextoPunto(){
        System.out.print("Ingrese el sexo de la persona('M' para mujer y 'H' para hombre ): ");
        
        char sexo='r';
        float altura;

        //Exigiendo un dato correcto desde consola, si no es correcto, se volvera a pedir
        while(true){
            //pidiendo el sexo desde consola
            sexo=scan.next().charAt(0);
            if(sexo!='H' && sexo!='M'){
                System.out.print("Recuerde los parametros iniciales, vuelva a escribir el sexo : ");
                continue;
            }
            //llegados a este punto, ya se cuenta con un dato valido
            break;
        }

        //Pidiendo el dato de altura desde consola
        System.out.println("Agregue la altura de la persona");
        altura=scan.nextFloat();

        //imprimiendo el resultado con la operacion dentro
        System.out.println("El peso ideal para la persona es de "+ pesoIdeal(sexo, altura));
    }

    /**
     * Calcula el peso ideal dado los lineamientos del punto 5
     * @param sexo contiene el sexo de la persona(solo se acepta 'H' para hombre, y 'M' para mujer)
     * @param altura altura de la persona en cuestion
     * @return peso ideal de la persona
     */
    private float pesoIdeal(char sexo,float altura){
        return (sexo=='H')?altura-110:(sexo=='M')?altura-120:0;
        //El codigo anterior hace lo mismo que el siguiente codigo:
        /*
            float pesoIdeal;
            if(sexo=='H'){
                pesoIdeal=altura-110;
            }else if(sexo=='M'){
                pesoIdeal=altura-120;
            }else{
                pesoIdeal=0;
            }
            return pesoIdeal;
        */
    }


    /**
     * Solucion del septimo punto
     */
    public void septimoPunto(){
        System.out.println("Vamos a evaluar si los numeros que ingresas son primos");
        boolean seguir=false;
        int numero;

        //se usa la estructura do ya que minimo debe de entrar una vez en el bloque de codigo
        do{
            System.out.print("Ingresa el numero a evaluar: ");

            //recibiendo desde consola el numero a evaluar
            numero=scan.nextInt();
            System.out.println(isPrimo(numero)?"El numero "+numero+" si es un numero primo": "El numero "+numero+" no es numero primo");
            
            //Evaluando si se quiere continuar intentando con mas numeros
            System.out.print("Quieres probar con otro numero? si:Y, no:cualquier otro : ");
            seguir=(scan.next().equals("Y"));

        }while(seguir);
        System.out.println("Gracias por jugar!!!");
    }


    /**
     * Evalua si un numero es primo o no
     * @param numero numero a evaluar
     * @return booleano que define si "numero" es primo o no
     */
    public boolean isPrimo(int numero){
        /*
        Un numero primo es aquel que solo es divisible por si mismo y por uno
        por consiguiente, si se encuentra otro divisor, el numero ya no es primo
        para ahorrar trabajo computacional:
            * Se puede comenzar a hacer la validacion desde el numero 3(obliga a un caso inicial extra para el valor 2)
            * Los divisores como mucho van hasta la mitad del valor del numero a evaluar(claro sin tener en cuenta el numero en cuestion)
            * Si se es mas minucioso, tambien se pueden evitar todos los numeros pares sin contar el 2
        estos casos implican colocar a mano los casos iniciales que no son abarcados por el for
        */

        //Casos iniciales
        //el numero 2 es numero primo(se pone explicito para que en el for se puedan hacer saltos de 2 en dos)
        if(numero==2)
            return true;
        //los numeros 0, 1 y los numeros pares(sin contar el 2) no son considerados numeros primos, 
        if(numero==1 || numero==0 || numero%2==0)
            return false;
        
        
        //Validando todos los posibles divisores hasta la mitad del numero
        for(int i=3; i<=numero/2;i+=2){
            //evaluando si es o no divisor
            if(numero%i==0){
                return false;
            }
        }

        return true;
    }



    /**
     * Solucion del octavo punto
     */
    public void octavoPunto(){
        System.out.println("RECUERDE LAS SIGUIENTES DIRECTRICES: T:tijera, P:piedra, L:papel");

        //Bucle que solo para si el usuario no quiere continuar con el juego
        while(true){
            //Pidiendo la opcion del primer jugador
            System.out.print("Introduzca la opcion para el jugador #1 : ");
            char opcion_1=obtenerOpcionPiedraPapelTijera(); //la funcion "obtenerOpcionPiedraPapelTijera()" se encarga de validar si la opcion ingresada es correcta o no

            //Pidiendo la opción del segundo jugador
            System.out.print("Introduzca la opcion para el jugador #2 : ");
            char opcion_2=obtenerOpcionPiedraPapelTijera(); //la funcion "obtenerOpcionPiedraPapelTijera()" se encarga de validar si la opcion ingresada es correcta o no
            
            //Consultando el ganador por medio de la funcion "ganadorPiedraPapelTijera()"  e imprimiendolo
            System.out.println("El ganador del juego es el jugador #"+ganadorPiedraPapelTijera(opcion_1, opcion_2));
            
            //Consultando si se quiere o no continuar con el juego
            System.out.println("Quisiera volver a intentarlo? Y:si, otros:no");
            if(!scan.next().equals("Y"))
                break;
        }
    }

    /**
     * Define que jugador gano un juego de piedra papel o tijera
     * @param opcion_primer_jugador opción de juego para el primer jugador
     * @param opcion_segundo_jugador opción de juego para el segundo jugador
     * @return el numero del jugador ganador
     */
    private int ganadorPiedraPapelTijera(char opcion_primer_jugador,char opcion_segundo_jugador){
        //Validando todas las opciones del juego
        if(opcion_primer_jugador=='P'){
            if(opcion_segundo_jugador=='L'){
                return 2;
            }else if(opcion_segundo_jugador=='T'){
                return 1;
            }
        }else if(opcion_primer_jugador=='L'){
            if(opcion_segundo_jugador=='T'){
                return 2;
            }else if(opcion_segundo_jugador=='P'){
                return 1;
            }
        }else if(opcion_primer_jugador=='T'){
            if(opcion_segundo_jugador=='P'){
                return 2;
            }else if(opcion_segundo_jugador=='L'){
                return 1;
            }
        }

        //Llegados a este punto, ningunjugador gano, osease, empate
        return 0;

    }

    /**
     * Pide por consola la opcion para un jugador en el juego de piedra papel o tijera
     * @return la opcion dada por consola
     */
    private char obtenerOpcionPiedraPapelTijera(){
        char opcion;

        //Se valida si la opcion esta en los parametros
        while(true){
            opcion=scan.next().charAt(0);
            if(!(opcion!='T' && opcion!='P' && opcion!='L'))
                return opcion;
            else
                System.out.print("Recuerde los parametros iniciales, vuelva a intentarlo: ");  
        }
        
    }
}
